const GEMINI_API_KEY = "AIzaSyDx5Jl-WC28YGtamE8xncqu9KgSd-zR-sg";
const GEMINI_MODEL = "gemini-3-flash-preview";
const SUPABASE_URL = "https://lgueqndrxxkcssjclyxp.supabase.co";
const SUPABASE_ANON_KEY = "sb_secret_pP-K27E7DIXY5s58BiUdmA_d5a4WRpx";
export {
  GEMINI_MODEL as G,
  SUPABASE_URL as S,
  GEMINI_API_KEY as a,
  SUPABASE_ANON_KEY as b
};
