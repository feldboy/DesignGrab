import "./modulepreload-polyfill-DaKOjhqt.js";
const btnFigma = document.getElementById("btn-figma");
const btnInspect = document.getElementById("btn-inspect");
const btnAssets = document.getElementById("btn-assets");
const btnPanel = document.getElementById("btn-panel");
btnFigma.addEventListener("click", () => {
  chrome.storage.local.set({ openTab: "figma" });
  chrome.runtime.sendMessage({ type: "OPEN_SIDE_PANEL" });
  setTimeout(() => window.close(), 200);
});
btnInspect.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "TOGGLE_INSPECT" }, (response) => {
    if (response?.active) {
      btnInspect.classList.add("active");
      btnInspect.querySelector("span").textContent = "Stop Inspecting";
      setTimeout(() => window.close(), 300);
    } else {
      btnInspect.classList.remove("active");
      btnInspect.querySelector("span").textContent = "Start Inspecting";
    }
  });
});
btnAssets.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "EXTRACT_ASSETS" }, (response) => {
    if (response?.success) {
      chrome.runtime.sendMessage({ type: "OPEN_SIDE_PANEL" });
      chrome.storage.local.set({ lastExtractedAssets: response.assets });
      setTimeout(() => window.close(), 300);
    }
  });
});
btnPanel.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "OPEN_SIDE_PANEL" });
  setTimeout(() => window.close(), 200);
});
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs[0]) {
    chrome.tabs.sendMessage(tabs[0].id, { type: "PING" }, (response) => {
      if (chrome.runtime.lastError) return;
    });
  }
});
